using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameTimer : MonoBehaviour
{
    public float levelSeconds;

    private LevelManager levelmanager;
    private AudioSource levelcompleteaudio;
   // public AudioSource levelAudio;
    private bool isEndOfLevel = true;
    public GameObject winlabel;
    //private float secondleft;

    private Slider gameTimer;

    private void Awake()
    {
        //levelAudio.Play();
    }
    // Start is called before the first frame update
    void Start()
    {
        gameTimer = gameObject.GetComponent<Slider>();
        levelcompleteaudio = gameObject.GetComponent<AudioSource>();
        levelmanager = FindObjectOfType<LevelManager>();

        //secondleft = levelSeconds;

    }

    // Update is called once per frame
    void Update()
    {
        
        gameTimer.value = Time.timeSinceLevelLoad / levelSeconds;
        if((Time.timeSinceLevelLoad) >= levelSeconds && isEndOfLevel)
        {
            
            //levelAudio.Stop();
            levelcompleteaudio.Play();
            winlabel.SetActive(true);
            Invoke("loadNextLevel", levelcompleteaudio.clip.length);
            print("level complete........");
            isEndOfLevel = false;

        }
    }
    void loadNextLevel()
    {
        levelmanager.LoadLevel("03awin");
        winlabel.SetActive(false);

    }

}
